<template>
<div>
	<div class="meeting-upload main" >
		<div class="meeting-header">
			<i class="icon-bg meeting-header-icon"></i>
			<span>会议上传</span>
		</div>
		<div class="upload-content clearfloat">
			<div class="upload-left">
				<div class="upload-title" noselect>大会日程</div>
				<div class="upload-content">
					<div class="schedule-day">
						<div noselect>
							{{schedulesDays[processDaysIdx].date}} 
						</div>
						<div @click="lastDay" noselect  class="last-day">
							上一天
						</div>
						<div @click="nextDay" noselect  class="next-day">
							下一天
						</div>
					</div>
					<div class="schedule-info">
						<div>
							<div v-for="(schedule,scheduleIdx) in schedulesDays[processDaysIdx].schedules" :key="scheduleIdx">
								<div class="schedule-info-duration">{{schedule.timeStart.HH+':'+schedule.timeStart.mm+'-'+schedule.timeEnd.HH+':'+schedule.timeEnd.mm}}</div>
								<div >
									<div class="schedulePices" v-for="(schedulePice,schedulePiceIdx) in schedule.schedulePices" :key="schedulePiceIdx"> 
										<div class="schedule-info-other" v-if="schedulePice.meetTypeSelected==='other'">
											{{schedulePice.title}}
										</div>
										<div class="schedule-info-speak-wrap" v-else>
											<div class="schedule-info-speak clearfloat" :style="isProcessDaysIdx===processDaysIdx&&isSchedulePiceIdx===schedulePiceIdx&&isScheduleIdx===scheduleIdx?{backgroundColor:'#cdffb7'}:{}">
												<div class="speak-model">{{schedulePice.tag||'标签'}}</div>
												<div class="speak-info" >
													<img class="speaker-header" :src="schedulePice.info.head">
													<div class="speaker-wrap">
														<div class="speak-title" ellipsis>{{schedulePice.title}}</div>
														<div class="spaker">{{schedulePice.spakerName||'演讲者'}}</div>
													</div>
													
													<div class="pice-edite">
														<span @click="schedulePiceEdite(processDaysIdx,scheduleIdx,schedulePiceIdx)"  v-if="!schedulePice.edited">编辑</span>
														<i v-else class="icon-bg pice-edited-icon"></i>
													</div>
												</div>
												<div></div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div>
			<div class="upload-right">
				<div class="upload-right-create">
					<label for="">作者信息：</label>
					<input v-model="speakerName" placeholder="请输入作者姓名" type="text">
					<span  class="upload-header-wrap">
						上传头像
						<img class="upload-header-preview" :src="previewHeadUrl" alt="">
						<input title="点击上传头像" @change="chooseHeadImg" class="upload-header-input" type="file">
					</span>
					
				</div>
				<div class="upload-right-create" style="margin-top:0;">
					<label for="">演讲标签：</label>
					<input v-model="tag"  class="upload-header-input" type="text" placeholder="请输入演讲标签">
				</div>
				<div class="upload-right-upload clearfloat">
					<label for="">上传ppt：</label>
					<div  class="right-upload-content">
							<span class="upload-btn-wrap">
								<span class="upload-btn">上传PPT</span>
								<input @change="choosePpt"  title="点击上传PPT"  class="upload-btn-input" type="file">
							</span>
							
							<br>
							<span class="upload-tit">或拖拽PPT至此处</span>
					</div>
				</div>
				<div class="upload-right-intro">
					<label for="">PPT简介：</label>
					<textarea v-model="pptIntro" class="right-intro-content" name="" id="" cols="30" rows="10"></textarea>
				</div>
				<div @click="savePice" style="font-size:16px;color: #6195ff;margin:14px 0 0 4px;cursor:pointer;">
					<label for="" style="opacity:0">PPT简介：</label>
					<span >保存当前</span>
				</div>
			</div>

		</div>
		<div class="meeting-nav">
				<router-link class="meeting-cancel" :to="{path: 'create'}">取消</router-link>
				<span class="meeting-sumbit" @click="sendData">完成</span>
		</div>
	</div>
	 <!-- 登陆 -->
   	<login></login>
</div>
</template>
<script>
import {validate} from '@/assets/js/validate' //注意路径
import	login from "@/components/base/login"
import axios from 'axios'
	export default{
		components:{login},
		data(){
			return{
				schedulesDays:{},//上个页面传来的日程安排
				daysIdx:0,//天的索引用来切换填写当天日程
				previewHeadUrl:'',//右边编辑区域选择图片的本地路径
				currentSpeakerImgFile:{},//右边编辑区域选择图片文件，.png/jpg/jpeg
				speakerName:'',//右边当前操作ppt的演讲人
				pptIntro:'',//右边ppt简介
				pptfile:{},//右侧每个所选择的ppt文件 ，.pptx
				scheduleIdx:0,
				schedulePiceIdx:0,
				isProcessDaysIdx:0,
				isScheduleIdx:0,
				isSchedulePiceIdx:0,
				tag:''

			}
		},
		computed:{
			processDaysIdx(){ //当前操作天数
				return Math.min(this.schedulesDays.length,Math.max(0,this.daysIdx))
			}
		},
		methods:{
			lastDay(){
				this.daysIdx--
			},
			nextDay(){
				this.daysIdx++
			},
			schedulePiceEdite(processDaysIdx,scheduleIdx,schedulePiceIdx){
				console.log(processDaysIdx,scheduleIdx,schedulePiceIdx)
				this.isProcessDaysIdx = processDaysIdx
				this.isScheduleIdx = scheduleIdx
				this.isSchedulePiceIdx = schedulePiceIdx


				this.schedulePiceIdx = schedulePiceIdx; //指定当前操作日程块内ppt索引
				this.scheduleIdx = scheduleIdx;//指定当前操作日程分区索引
				// 清空右侧表单内容
				this.previewHeadUrl = '';
				this.speakerName='';
				this.pptIntro='';
				this.tag = ''
			},
			chooseHeadImg(e){//选择每个用户的头像
				let file = e.target.files[0]
				this.currentSpeakerImgFile = file
			   	this.previewHeadUrl = window.URL.createObjectURL(file);
			},
			dragenter(){ //拖入ppt改变样式
				this.dragContainerStyle = '#eee'
			},
			dragover(){//拖中改变样式
			},
			dragleave(){ //拖离改变样式
				this.dragContainerStyle = '#fff'
			},
			drop(event){ //释放ppt改变样式发送请求
				this.dragContainerStyle = '#fff';
				var files = event.dataTransfer.files;
				this.pptfile = files[0]
			},
			choosePpt(e){ //点击按钮选择PPT
				let files = e.target.files;
				this.pptfile = files[0]
			},
			savePice(){//点击保存按钮，将数据放到对应的schedulePice里面
				console.log(this.speakerName)
				console.log(this.currentSpeakerImgFile)
				console.log(this.pptfile)
				console.log(this.pptIntro)
				console.log(this.tag)


				let currentPice = this.schedulesDays[this.processDaysIdx].schedules[this.scheduleIdx].schedulePices[this.schedulePiceIdx]

				// let pptInfo = {
				// 	cover:  "",
				// 	pptUrl: "",
				// 	title: currentPice.title,
				// 	pptIntro: this.pptIntro,
				// 	speakerName: this.speakerName,
				// 	head: ""
				// }
				// currentPice.info = pptInfo
				console.log(currentPice)



				let form = new FormData() //上传ppt
		    	form.append('ppt_files',this.pptfile) //此处填写后端需要的name名
				axios.post('http://www.pptx.info/pptxzs/uploadppt.json?user_id='+sessionStorage.getItem('userId')+'&user_key='+sessionStorage.getItem('userKey'),form) 
			    .then((res) => {
			    		let data = res.data.data
						let pptId = data.ppt_id;


						



						let pptForm = new FormData()  //上传头像
						form.append('images',this.currentSpeakerImgFile) 
						axios.post('/pptxzs/uploadimage.json?user_id='+sessionStorage.getItem('userId')+'&user_key='+sessionStorage.getItem('userKey'),form) 
						.then((res)=>{
							let auth_head = res.data.data.url
							let auth_name = this.speakerName
							let desc = this.pptIntro
							let title = currentPice.title


							currentPice.info.head = auth_head  //动态改变当前编辑栏的内容
							currentPice.tag = this.tag
							currentPice.edited = true
							currentPice.ppt_id = pptId
							currentPice.content = title



							// 编辑ppt
							axios.post('/pptxzs/pptpicfile.json?user_id='+sessionStorage.getItem('userId')+'&user_key='+sessionStorage.getItem('userKey'),{
								title,
								auth_head,
								auth_name,
								desc,
								ppt_id:pptId
							},{
								headers: {'Content-Type': "application/x-www-form-urlencoded"} 
							})
							.then(res=>{
							
							})
						},(err)=>{

						})
						
			    },(err)=>{

			    })






				// var form = new FormData()  //上传文件到服务端
				// form.append('file',file)
				// axios.post('https://pptxzs.dolphin.com/',form,{
				// 	 headers: {'Content-Type': 'multipart/form-data'}
				// }).then(res=>{
				// 	var data = res.data.data
				// 	this.schedulesDays[this.processDaysIdx].schedules[this.scheduleIdx].schedulePices[this.schedulePiceIdx].info.head =data.speakerImg 
				// },err=>{

				// })
			},
			sendData(){
				var creatorName = this.speakerName;
				var head = this.currentSpeakerImgFile;//要上传到服务端的文件
				var pptfile = this.pptfile;//要上传到服务器的文件
				


				/**
				 * 
				 * 数据处理
				 * @type {[type]}
				 */
					var meetInfo = this.meetInfo;
					var schedulesDays = this.schedulesDays;


					/**
					 * 对scheules进行处理的函数
					 * @type {Array}
					 */
					var durationDays = [];  //用于小程序的时间tab栏
					var schedulesDaysArr = []; //用于小程序会议所有天数的详情页
					schedulesDays.forEach((v,i)=>{
						durationDays.push(
							{
					        	date: v.date
					     	}
						);
						schedulesDaysArr.push(v.schedules)//小程序中有用的schedules提取出来
					})
					schedulesDaysArr.forEach((v,i)=>{
						v.forEach((v,i)=>{

						})
					})
					schedulesDays = schedulesDaysArr;

					console.log(meetInfo)
					meetInfo.meetingHeader.durationDays =  durationDays;
					meetInfo.schedulesDays = this.schedulesDays 



					var formData = new FormData();   
					var file = validate.convertBase64UrlToBlob(meetInfo.cover)
					formData.append("images",file);  //append函数的第一个参数是后台获取数据的参数名,和html标签的input的name属性功能相同
					axios.post('/pptxzs/uploadimage.json?user_id='+sessionStorage.getItem('userId')+'&user_key='+sessionStorage.getItem('userKey'),formData,{
						 headers: {'Content-Type': 'multipart/form-data'}
					}).then(res=>{
						console.log(res)
						meetInfo.cover = res.data.data.url
						
					})
					
			}
		},
		created(){

			var meetInfo = JSON.parse(sessionStorage.getItem('meetInfo'))//获取从上个页面穿个的json数据
			this.meetInfo = meetInfo;
			var schedulesDays = meetInfo.schedulesDays
			schedulesDays.forEach((v,i)=>{ //给每一个会议pice设置一个为编辑状态
				v.schedules.forEach((v,i)=>{
					v.edited = false;
				})
			})

			this.schedulesDays = schedulesDays

		}
	}
</script>
<style lang="scss" >
	.meeting-upload{
		margin-top: 30px;
		background-color: #FFF;
		padding-bottom: 30px;
		min-height:600px;
		.meeting-header{
			height:103px;
			padding:20px 0 0 20px;
			.meeting-header-icon{
				background-image:url("../../assets/images/upload-meeting_03.png");
				width: 57px;
				height: 47px;
			}
		}
		.upload-content{
			.upload-left{
				width: 363px;
				float:left;
				margin-left: 20px;
				.upload-title{
						font-size: 24px;
						color: #353535; 
						text-align: center;
						margin-bottom: 20px;
						
				}
				.upload-content{
					border: solid 1px #999999;
					
					.schedule-day{
						position: relative;
						color: #6195ff;
						font-size: 16px;
						text-align: center;
						height: 40px;
						line-height: 40px;
						.next-day,.last-day{
							position: absolute;
							width: 60px;
							height:40px;
							top:0;
							cursor: pointer;
						}
						.next-day{
							right: 10px;
						}
						.last-day{
							left: 10px;
						}
						
					}
					.schedule-info{
						.schedule-info-duration{
							height: 20px;
							border-bottom: solid 1px #999999;
							border-top: solid 1px #999999;
							line-height: 20px;
							color: #999999;
							font-size: 12px;
						}
						.schedulePices{
							border-bottom: solid 1px #999999;
							.schedule-info-other{
								height: 40px;
								
								line-height: 40px;
								text-align: center;
								font-size: 16px;
							}
							.schedule-info-speak-wrap{
									
								.schedule-info-speak{
									
									height: 60px;
									line-height: 60px;
								
									.speak-model{
										float: left;
										width: 120px;
										border-right:solid 1px #999999;
										text-align: center;
										font-size: 16px;
									}
									.speak-info{
										position: relative;
										padding-left: 10px;
										box-sizing: border-box;
										float: left;
										width: 240px;
										.speaker-header{
											width: 32px;
											height: 32px;
											border-radius: 50%;
											background-color: #eee;
											float: left;
											margin-top: 14px;
										}
										.speaker-wrap{
											float: left;
											line-height: 30px;
											color:#888;
											padding-left: 10px;
											box-sizing: border-box;
											.speak-title{
												// display: inline-block;
												font-size: 14px;
												height: 30px;
												width: 180px;
											}
											.spaker{
												// display: inline-block;
												height: 30px;
												font-size: 12px;
												width: 180px;
											}
										}
										.pice-edite{
											position: absolute;
											width: 40px;
											height:40px;
											right:-60px;
											cursor: pointer;
											color: #6195ff;
											font-size: 13px;
											line-height: 40px;
											margin-top: 12px;
											.pice-edited-icon{
												background-image: url("../../assets/images/complish_03.png");
												width:24px;
												height:24px;
											}
										}

									}
									
								}
							}
						}
						.schedulePices:last-child{
							border-bottom:none;
						}
						
						
					}
					
				}
			}
			.upload-right{
				float:left;
				width: 482px;
				padding-left: 80px;
				label{
					width: 80px;
					text-align: right;
				}
				.upload-right-create{
					height:60px;
					margin-top: 42px;
					line-height: 60px;
					label{
						font-size: 16px;
					}
					input{
						height: 30px;
						width: 120px;
						padding-left: 10px;
						box-sizing: border-box;
					}
					margin-bottom: 20px;
					.upload-header-wrap{
						display: inline-block;
						width: 60px;
						height: 60px;
						font-size: 12px;
						text-align: center;
						line-height: 60px;
						border-radius: 50%;
						margin-left: 20px;
						position: relative;
						vertical-align: middle;
						background-color: #999;
						input,img{
							width: 100%;
							height: 100%;
							position: absolute;
							left: 0;
							right: 0;
							border-radius: 50%;
						}
						.upload-header-preview{
							cursor: pointer;
						}
						.upload-header-input{
							opacity: 0;
							z-index: 1;
							cursor: pointer;
						}
					}

				}
				.upload-right-upload{
					margin: 0 0 30px 0;
					label{
						float: left;
						font-size: 16px;
					}
					.right-upload-content{
						float: left;
						width: 320px;
						height: 180px;
						text-align: center;
						font-size: 16px;
						margin-left: 4px;

						border: solid 1px #999;
						.upload-btn-wrap{
							position: relative;
							display: inline-block;
							width: 140px;
							height: 30px;
							background-color: #6195ff;
							border-radius: 5px;
							color: #ffffff;
							line-height: 30px;
							margin: 61px 0 10px;
							span,input{
								position: absolute;
								width: 100%;
								height: 100%;
								left: 0;
								top: 0;
							}
							.upload-btn{
								
							}
							.upload-btn-input{
								opacity: 0;
								z-index: 1;
								cursor: pointer;

							}
						}
						
						.upload-tit{
							color: #999999;
						}
					}


				}
				.upload-right-intro{
					
					label{
						
						font-size: 16px;
					}
					.right-intro-content{
						margin-left: 4px;
						vertical-align: top;
						width: 320px;
						height: 140px;
					}

				}
			}
		}
		.meeting-nav{
			text-align: center;
			margin-top: 80px;
			.meeting-cancel,.meeting-sumbit{
				display: inline-block;
				width: 180px;
				height: 50px;
				line-height: 50px;
				background-color: #6195ff;
				border-radius: 5px;
				font-size: 22px;
				color:#fff;
				cursor: pointer;
			}
			.meeting-cancel{
				margin-right: 120px;
			}
			
		}
	}
</style>